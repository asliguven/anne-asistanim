# Anne Asistanım — Yayına Alma Kontrol Listesi

- [ ] Node.js 20+ kur
- [ ] `npm install`
- [ ] `npm run dev`
- [ ] Telefonda /start, /cocuk, /yemek, /ev, /ben, /kaynaklar kontrol et
- [ ] GitHub repo oluştur
- [ ] Projeyi GitHub'a yükle
- [ ] Vercel'e bağla ve Deploy et
- [ ] Domaini bağla
- [ ] Instagram @anneasistanim uygunluğunu kontrol et
- [ ] Instagram bio'ya /start linkini koy
- [ ] Instagram'da ilk 30 günlük plana başla
- [ ] E-posta formu için sonraki fazda bir e-posta sağlayıcısı bağla
- [ ] Gerçek analytics için sonraki fazda GA4/alternatif analytics ekle
