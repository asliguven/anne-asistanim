# Anne Asistanım — MVP

## Hazır olanlar
- Mobile-first Next.js + TypeScript + Tailwind iskeleti
- Ana sayfa ve /start Instagram landing
- Çocuğum: 200 aktivite
- Yemek: 100 tarif + 20 haftalık menü
- Ev: 50 plan
- Ben: 50 içerik
- Kaynaklar: 100 printable
- Toplam içerik kaydı: 520
- Alışveriş listesi
- Yazdırılabilir kaynak sayfaları
- Sitemap + robots
- Web + Instagram Content Center
- İlk 30 günlük Instagram planı
- AI chatbot yok
- Ödeme yok
- Zorunlu üyelik yok

## Bilgisayarda çalıştırma
Node.js 20+ kurulu olsun. Terminal:
1. `npm install`
2. `npm run dev`
3. `http://localhost:3000`

## İnternete koyma
En kolay yöntem: GitHub reposuna yükle → Vercel'de import et → Deploy.
Vercel'in verdiği geçici adresle siteyi hemen test edebilirsin.

## Domain
Vercel → Project → Settings → Domains bölümünden domaini ekle.
Domaini satın aldığın firmanın DNS ekranına Vercel'in gösterdiği kayıtları gir.

## Instagram
`@anneasistanim` uygunsa hesabı aç. Kullanıcı adı uygunluğunu Instagram uygulamasında kontrol et.
Bio linki: `https://anneasistanim.com/start` (domain gerçekten bağlandıktan sonra).

## Yeni içerik
MVP'de içerikler `content/data.json` içinde. Yeni içerik ekleyip yeniden deploy edilir.
İlerleyen fazda bunu Supabase/CMS ile teknik olmayan kullanıcı için panelden ekleme sistemine çevirmek mantıklı.

## 10 aylık yönetim
Her ay yeni çocuk aktivitesi, tarif, printable, anne ve ev içeriği ekle.
Takip et: Google trafiği, Instagram tıklaması, sayfa görüntüleme, printable kullanımı/indirmesi ve e-posta kayıtları.
İlk 10 ay premium kilidi, ödeme ve AI chatbot açma.

## İçerik merkezi
`content/content-center.json` içinde her içerik için Content ID, web URL, Instagram hook/caption/CTA, içerik tipi, status ve yayın tarihi alanları bulunur.
