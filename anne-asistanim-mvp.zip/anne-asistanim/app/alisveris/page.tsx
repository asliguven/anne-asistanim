'use client';
import {useState} from 'react';
export default function Shopping(){
 const [items,setItems]=useState<string[]>(['Süt','Yumurta','Domates']); const [v,setV]=useState('');
 return <div className="container py-12"><h1 className="text-4xl font-black">Alışveriş Listem</h1>
 <p className="text-gray-600 mt-3">Kendi listenizi oluşturun, işaretleyin ve yazdırın.</p>
 <div className="card p-6 max-w-xl mt-8">
 <div className="flex gap-2"><input value={v} onChange={e=>setV(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&v.trim()){setItems([...items,v.trim()]);setV('')}}} placeholder="Madde ekle" className="border rounded-full px-4 py-3 flex-1"/>
 <button onClick={()=>{if(v.trim()){setItems([...items,v.trim()]);setV('')}}} className="btn btn-primary">Ekle</button></div>
 <div className="mt-6 space-y-3">{items.map((x,i)=><label key={i} className="flex gap-3 items-center"><input type="checkbox" className="w-5 h-5"/><span>{x}</span></label>)}</div>
 <button onClick={()=>setItems([])} className="btn btn-soft mt-6">Listeyi temizle</button>
 <button onClick={()=>window.print()} className="btn btn-soft mt-2 ml-2">Yazdır</button>
 </div></div>
}
