import {findBySlug} from '../../../lib/content'; import Link from 'next/link';
export default function Detail({params}:{params:{slug:string}}){
 const item:any=findBySlug(params.slug);
 if(!item)return <div className="container py-20"><h1>İçerik bulunamadı.</h1></div>;
 return <div className="container py-12"><div className="max-w-3xl mx-auto">
 <Link href="/cocuk" className="text-sm font-bold">← Geri dön</Link>
 <div className="card p-7 md:p-10 mt-5">
 <span className="text-sm font-bold text-[#7D6C75]">{item.category||item.type} {item.duration?`• ${item.duration}`:""}</span>
 <h1 className="text-4xl font-black mt-3">{item.title}</h1>
 {item.description && <p className="text-gray-600 text-lg mt-4">{item.description}</p>}
 {item.materials && <><h2 className="font-black text-xl mt-8">Gerekli malzemeler</h2><ul className="list-disc pl-6 mt-3">{item.materials.map((m:string)=><li key={m}>{m}</li>)}</ul></>}
 {item.ingredients && <><h2 className="font-black text-xl mt-8">Malzemeler</h2><ul className="list-disc pl-6 mt-3">{item.ingredients.map((m:string)=><li key={m}>{m}</li>)}</ul></>}
 {item.how_to && <><h2 className="font-black text-xl mt-8">Nasıl yapılır?</h2><p className="mt-3 leading-7">{item.how_to}</p></>}
 {item.method && <><h2 className="font-black text-xl mt-8">Yapılış</h2><p className="mt-3 leading-7">{item.method}</p></>}
 {item.steps && <><h2 className="font-black text-xl mt-8">Plan</h2><ol className="list-decimal pl-6 mt-3 space-y-2">{item.steps.map((s:string)=><li key={s}>{s}</li>)}</ol></>}
 {item.parent_note && <div className="mt-8 p-4 rounded-2xl bg-[#efe7e3]"><b>Ebeveyne küçük not:</b><p className="mt-1">{item.parent_note}</p></div>}
 {item.note && <div className="mt-8 p-4 rounded-2xl bg-[#efe7e3]"><b>Not:</b><p className="mt-1">{item.note}</p></div>}
 {item.type==="printable" && <div className="mt-8 flex gap-3"><a href={item.printable_url} target="_blank" className="btn btn-primary">Görüntüle / Yazdır</a><a href={item.printable_url} download className="btn btn-soft">İndir</a></div>}
 </div></div></div>
}
