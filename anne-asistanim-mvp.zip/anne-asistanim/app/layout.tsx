
import './globals.css'; import Header from '../components/Header'; import Footer from '../components/Footer';
export const metadata={title:'Anne Asistanım | Annelik biraz daha kolay olsun.',description:'Çocuk, yemek, ev, anne zamanı ve ücretsiz printable kaynakları tek yerde.'};
export default function Layout({children}:{children:React.ReactNode}){return <><Header/><main>{children}</main><Footer/></>}
