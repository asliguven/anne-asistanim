
import Link from 'next/link';
import {content} from '../lib/content';
import ContentCard from '../components/ContentCard';
export default function Home(){
 const featured=content.children.slice(0,6);
 return <div>
  <section className="container py-16 md:py-24 grid md:grid-cols-2 gap-10 items-center">
   <div><span className="inline-block px-4 py-2 rounded-full bg-[#efe7e3] text-[#463C4A] font-bold text-sm">🎁 İlk 10 ay tamamen ücretsiz</span>
   <h1 className="text-5xl md:text-7xl font-black tracking-tight mt-5">Annelik biraz daha kolay olsun.</h1>
   <p className="text-lg text-gray-600 mt-5 max-w-xl">Çocuğun, evin ve kendin için ihtiyacın olan fikirleri, planları ve ücretsiz kaynakları tek yerde bul.</p>
   <div className="flex flex-wrap gap-3 mt-7"><Link href="/start" className="btn btn-primary">Ücretsiz Keşfet</Link><Link href="/kaynaklar" className="btn btn-soft">Kaynaklara Göz At</Link></div></div>
   <div className="card p-8 bg-white"><div className="text-5xl">🧸 🍝 🏠 🌸</div><h2 className="text-2xl font-black mt-5">Bugün neye ihtiyacın var?</h2><div className="grid grid-cols-2 gap-3 mt-5">{[['🧸','Çocuğum','/cocuk'],['🍝','Yemek','/yemek'],['🏠','Ev','/ev'],['🌸','Ben','/ben']].map(([i,t,u])=><Link key={t} href={u} className="card p-4 bg-[#FBF8F3]"><div className="text-2xl">{i}</div><b>{t}</b></Link>)}</div></div>
  </section>
  <section className="bg-[#463C4A] text-white py-10"><div className="container text-center"><h2 className="text-2xl font-black">Tüm içerikler ücretsiz.</h2><p className="mt-2 text-white/80">İlk 10 ay boyunca printable'lar, planlar ve içeriklerin tamamına erişebilirsin.</p></div></section>
  <section className="container py-16"><div className="flex justify-between items-end mb-7"><div><p className="text-sm font-bold text-[#7D6C75]">ÇOCUĞUM</p><h2 className="text-3xl font-black">Bugün deneyebileceğin fikirler</h2></div><Link href="/cocuk" className="font-bold">Tümünü gör →</Link></div><div className="grid md:grid-cols-3 gap-5">{featured.map((x:any)=><ContentCard key={x.id} item={x} base="/cocuk"/>)}</div></section>
  <section className="container pb-10"><div className="card p-8 md:p-10 flex flex-col md:flex-row gap-6 items-center justify-between"><div><h2 className="text-2xl font-black">Her hafta yeni ücretsiz kaynaklar.</h2><p className="text-gray-600 mt-2">Yeni fikirler ve printable'lar e-posta kutuna gelsin.</p></div><form className="flex w-full md:w-auto gap-2"><input required type="email" placeholder="E-posta adresin" className="rounded-full border px-4 py-3 flex-1"/><button className="btn btn-primary" type="button">Kaydol</button></form></div></section>
 </div>
}
