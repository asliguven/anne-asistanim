
import Link from 'next/link';
export default function ContentCard({item,base}:{item:any,base:string}){
 return <Link href={`${base}/${item.slug}`} className="card block p-5 hover:-translate-y-1 transition">
  <div className="text-xs font-bold text-[#7D6C75] mb-2">{item.category||item.type} {item.duration?`• ${item.duration}`:''}</div>
  <h3 className="font-extrabold text-lg mb-2">{item.title}</h3>
  <p className="text-sm text-gray-600 line-clamp-2">{item.description||item.parent_note||item.note||item.method||item.how_to}</p>
  <div className="mt-4 text-sm font-bold text-[#463C4A]">Detayları gör →</div>
 </Link>
}
