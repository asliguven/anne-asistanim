
export default function Footer(){return <footer className="mt-20 border-t border-[#eee6df] py-10"><div className="container text-sm text-gray-600 flex flex-col gap-3 md:flex-row md:justify-between"><span>© 2026 Anne Asistanım</span><span>Annelik biraz daha kolay olsun. 🌸</span></div></footer>}
