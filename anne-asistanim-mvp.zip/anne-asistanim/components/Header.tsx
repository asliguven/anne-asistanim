
import Link from 'next/link';
export default function Header(){
 const nav=[['ANA SAYFA','/'],['ÇOCUĞUM','/cocuk'],['YEMEK','/yemek'],['EV','/ev'],['BEN','/ben'],['KAYNAKLAR','/kaynaklar'],['ALIŞVERİŞ','/alisveris'],['INSTAGRAM','https://instagram.com/anneasistanim']];
 return <header className="sticky top-0 z-50 bg-[#FBF8F3]/95 backdrop-blur border-b border-[#eee6df]">
  <div className="container flex items-center justify-between h-16 gap-4">
   <Link href="/" className="font-black text-xl text-[#463C4A]">Anne Asistanım <span className="text-[#D9A6B5]">🌸</span></Link>
   <nav className="hidden md:flex gap-5 text-sm font-bold">{nav.map(([n,u])=>u.startsWith('http')?<a key={n} href={u} target="_blank">{n}</a>:<Link key={n} href={u}>{n}</Link>)}</nav>
   <Link href="/start" className="btn btn-primary text-sm">Ücretsiz Keşfet</Link>
  </div>
 </header>
}
