
import data from '../content/data.json';
export const content=data;
export function all(){return [...data.children,...data.recipes,...data.menus,...data.home,...data.mom,...data.printables]}
export function findBySlug(slug:string){return all().find((x:any)=>x.slug===slug)}
