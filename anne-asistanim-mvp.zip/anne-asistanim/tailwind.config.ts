import type {Config} from 'tailwindcss';
const config:Config={content:['./app/**/*.{js,ts,jsx,tsx}','./components/**/*.{js,ts,jsx,tsx}'],theme:{extend:{colors:{cream:'#FBF8F3',sage:'#9BAF9A',rose:'#D9A6B5',plum:'#463C4A',ink:'#28252A'}}}};export default config;
